# SRS Signed Receipt Profile v0.1

## 1. Status and scope

This profile defines the cryptographic mechanics for signed SRS envelopes. It is the standard-layer authority for signature construction and verification. Runtime implementations MUST conform to this profile and MUST NOT redefine the signed preimage, encoding, trust, or failure semantics.

This profile detects post-issuance semantic modification under an explicitly supplied issuer key. It does not establish that the issuer recorded the first or only version of an event, and it does not establish institutional trust in an issuer without a verifier-selected trust bundle.

## 2. Normative identifiers

A conforming signature object MUST use:

- `algorithm`: `Ed25519`
- `canonicalization`: `RFC8785-JCS`
- `key_id`: a non-empty, issuer-namespaced identifier
- `signature`: an unpadded base64url encoding of the 64-byte Ed25519 signature

A conforming public key entry MUST carry the raw 32-byte Ed25519 public key encoded with unpadded base64url. Standard base64, padded base64url, PEM text, and implementation-specific key objects are not conforming representations for this profile.

## 3. Signature object

`receipt_signature` MUST be an object with exactly these required members:

```json
{
  "algorithm": "Ed25519",
  "canonicalization": "RFC8785-JCS",
  "key_id": "issuer.example/receipt-signing/2026-01",
  "signature": "unpadded-base64url"
}
```

Additional signature-object members MUST NOT appear in v0.1. Legacy receipts carrying `receipt_signature` as a string are outside this profile and MUST be reported as `legacy_unverified`, not as valid signed receipts.

## 4. Signed preimage freeze point

This section is the signed-preimage freeze point. Merging this section unblocks verifier, emitter, and cross-language vector work.

The signed preimage MUST be constructed as follows:

1. Parse the complete receipt envelope into an I-JSON-compatible data model.
2. Require `receipt_signature` to be an object containing `algorithm`, `canonicalization`, `key_id`, and `signature`.
3. Create an exact semantic copy of the complete envelope.
4. Remove only `receipt_signature.signature` from that copy. The member is omitted, not set to `null` or an empty string.
5. Preserve `receipt_signature.algorithm`, `receipt_signature.canonicalization`, `receipt_signature.key_id`, `receipt_version`, `profile_id`, `profile_version`, every extension, and every unknown field.
6. Canonicalize the resulting complete data model with RFC 8785 JSON Canonicalization Scheme.
7. Sign the canonical UTF-8 bytes with Ed25519 under RFC 8032.

Unknown extension fields are signed when present. Adding, removing, or changing an unknown extension is a semantic mutation and MUST invalidate the signature. A `key_id` mutation changes the signed content and MUST fail signature verification even before trust policy is considered.

## 5. Canonicalization requirements

Implementations MUST use a maintained RFC 8785 implementation and MUST pass the official RFC 8785 examples and vectors vendored by the standard. Sorting object keys and calling a general-purpose JSON serializer is not sufficient.

Inputs containing NaN, positive or negative Infinity, integers outside the I-JSON interoperable range, unpaired Unicode surrogates, or values not representable by the canonicalizer MUST fail with `preimage_canonicalization_failed`. Implementations MUST NOT coerce such values into strings or substitute `null`.

Whitespace, indentation, object-key order, and line-ending changes outside JSON string values do not alter the JCS data model. Such reserialization MUST continue to verify. Any change to signed semantic content MUST fail.

## 6. Trust bundle and key rotation

Verification requires an explicit trust bundle selected by the verifier. A trust bundle MUST contain issuer entries with:

- `issuer_id`
- `key_id`
- `algorithm`
- `public_key`
- `not_before`
- `not_after`
- `trusted`

The verifier MUST report cryptographic signature validity, key resolution, and key trust separately. A receipt can be cryptographically valid under a resolved key while that key remains untrusted under the selected bundle.

Key identifiers SHOULD be namespaced by issuer and key purpose. Rotation SHOULD publish overlapping validity intervals so a verifier can validate receipts issued near the transition. A retired key MAY remain in a historical trust bundle after its issuance window closes.

No DID, JWKS, transparency-log, or network key-resolution mechanism is defined in v0.1.

## 7. Version binding

The complete `receipt_version`, `profile_id`, and `profile_version` fields are inside the signed preimage. A verifier MUST reject a receipt when the declared profile or envelope version is incompatible with the selected schema or profile, even when the Ed25519 signature is otherwise valid.

## 8. Verification verdicts and failure codes

A verifier MUST expose separate verdicts for:

- `signature_valid`
- `issuer_key_resolved`
- `issuer_key_trusted`

The verifier MUST use stable failure codes, including at minimum:

- `preimage_canonicalization_failed`
- `signature_invalid`
- `key_id_unresolved`
- `key_untrusted`
- `version_binding_mismatch`
- `signature_object_invalid`
- `signature_encoding_invalid`
- `public_key_encoding_invalid`
- `legacy_unverified`

A single generic pass result MUST NOT hide an unresolved or untrusted key.

## 9. Mutation contract

Conformance vectors MUST prove:

- reordered keys preserve signature validity;
- whitespace-only reserialization preserves signature validity;
- a signed semantic field change fails;
- signature-byte mutation fails;
- `key_id` mutation fails;
- envelope or profile version mutation fails;
- an unknown signed extension added, removed, or changed fails.
