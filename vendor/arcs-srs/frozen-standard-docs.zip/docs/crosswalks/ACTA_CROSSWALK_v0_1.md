# SRS Signed Receipt and ACTA Field Crosswalk v0.1

## 1. Scope

This document maps SRS signed-receipt and MCP admission fields to `draft-farley-acta-signed-receipts-02`, dated 2026-06-28. The referenced ACTA document is an individual Internet-Draft. This crosswalk records field relationships only and makes no comparative or standards-status claim.

## 2. Field mapping

| SRS field or concept | ACTA field or concept | Mapping note |
|---|---|---|
| `receipt_id` | receipt identifier | Direct identifier role; syntax may differ. |
| `issued_at` | issuance timestamp | Direct temporal role. |
| `issuer_id` | issuer identity | SRS v0.1 resolves through an explicit trust bundle. |
| `receipt_signature.algorithm` | signature algorithm | SRS fixes Ed25519 for the profile. |
| `receipt_signature.canonicalization` | canonicalization declaration | SRS fixes RFC 8785 JCS. |
| `receipt_signature.key_id` | verification-key identifier | SRS key trust remains verifier-selected. |
| `receipt_signature.signature` | digital signature | Both bind canonical receipt content. |
| `profile_id` and `profile_version` | receipt type or profile semantics | SRS binds named conformance profiles inside the signed preimage. |
| `argument_digest` | request or input commitment | SRS excludes raw governed content and carries a digest. |
| `result_digest` | result or output commitment | SRS commits to the named semantic projection. |
| `disposition` | decision or restraint result | SRS uses admitted, refused, or deferred-for-review. |
| `review_object_ref` | review or escalation reference | SRS binds a durable review object by reference. |
| `admission_receipt_ref` | parent or linked receipt | SRS links an outcome to its admission receipt. |
| `attestation_limits` | limitations or scope statement | SRS requires explicit claims about what the receipt does not prove. |
| `artifact_classes_excluded` | disclosure-minimization declaration | SRS makes raw-content exclusion normative for the MCP profile. |
| transparency-log anchor | transparency-log anchoring | Not shipped by SRS Signed Receipt Profile v0.1. |
| selective-disclosure commitment | selective-disclosure mode | Not shipped by SRS Signed Receipt Profile v0.1. |

## 3. Interoperability posture

An implementation MAY produce both an SRS receipt and an ACTA representation from the same governed event. Such conversion MUST preserve the declared attestation limits and MUST NOT infer an admission, review, lifecycle, or custody claim absent from the source representation.
